<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</head>
<body class="text-black">
<main>
    <div class="border-b-2 px-10 flex flex-row items-center justify-between">    
    <div class="py-3">
        
        <h3 class="text-3xl font-bold">Recipe Management</h3>
      </div>
        
    </div>
    
    <div class="flex flex-row justify-start">
        <div class="w-64 h-screen border-solid border-r-2">
            <ul>
                <li class="px-6 py-3.5 duration-150 font-bold">Management</li>

                <li class="px-10 py-3.5 bg-gray-100 hover:bg-gray-200 transition ease-in-out duration-150 flex flex-row items-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-5"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path fill="#161513" d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304H178.3z"/></svg>
                    <a href="/recipes" class="ml-5">Recipes</a>
                </li>
            </ul>
        </div>
        <div class="w-full h-screen bg-neutral-100">
        <div class="m-7">
            <h2 class="text-3xl font-bold mb-7">Welcome Admin!</h2>
            <div class="w-full flex justify-end">
                <a href="/admin-addrecipe" class="bg-[#7bafed] hover:bg-[#8ebbed] transition ease-in-out duration-150 p-2 rounded-md mb-7 text-white"><strong>+</strong> Add Recipe</a>
            </div>
            <table
                class="min-w-full text-sm font-light dark:border-neutral-500">
                    <thead class="font-medium text-black dark:border-neutral-500">
                        <tr>
                            <th
                                scope="col"
                                class=" text-left dark:border-neutral-500 pb-3.5 pl-4">
                                NAME
                            </th>
                            <th
                                scope="col"
                                class=" text-left dark:border-neutral-500 pb-3.5">
                                QUANTITY
                            </th>
                            <th scope="col" class="text-left dark:border-neutral-500 pb-3.5">PRICE</th>
                            <th scope="col" class="text-left dark:border-neutral-500 pb-3.5" colspan="2">ACTION</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white">
                        <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-t border-b border-neutral-300 ease-in-out hover:bg-neutral-100">
                                <td class="flex flex-col whitespace-nowrap px-4 py-4 dark:border-neutral-500">
                                    <div class="mb-0.5">
                                        <?php echo e($cont->product_name); ?>

                                    </div>
                                </td>
                                <td class="whitespace-nowrap py-4 dark:border-neutral-500"><?php echo e($cont->quantity); ?></td>
                                <td class="whitespace-nowrap py-4 dark:border-neutral-500"><?php echo e($cont->price); ?></td>
                                <td
                                    class="whitespace-nowrap py-4 dark:border-neutral-500 ">
                                    <a href="<?php echo e(route('admin.editrecipe', ['id' => $cont->id] )); ?>"
                                        class="text-indigo-600 hover:text-indigo-900">
                                        <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="none"
                                            viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                        </svg>
                                    </a>
                                </td>
                                
                                <td
                                    class="whitespace-nowrap px-6 py-4 dark:border-neutral-500 ">
                                    <form action="<?php echo e(route('admin.deleterecipe',$cont->id)); ?>" method="GET" onsubmit="return confirm('<?php echo e(trans('Are you sure you want to delete this ? ')); ?>');">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="flex items-center">
                                        <svg xmlns="http://www.w3.org/2000/svg"
                                            class="w-6 h-6 text-red-600 hover:text-red-800 cursor-pointer" fill="none"
                                            viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                        </svg>
                                    </button>
                                    </form>
                                </td>
                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
        </div>
        

        </div>
        
    </div>
</main>
</body>
</html>
<?php /**PATH C:\Users\Acer\money-teller\resources\views/admin/recipes.blade.php ENDPATH**/ ?>