<div class="min-h-full">
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/example-app/resources/views/auth/layouts/header.blade.php ENDPATH**/ ?>