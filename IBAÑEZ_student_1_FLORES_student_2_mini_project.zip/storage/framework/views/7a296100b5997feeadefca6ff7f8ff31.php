</div> <!--Note: this is end of the .min-h-full-->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/example-app/resources/views/auth/layouts/footer.blade.php ENDPATH**/ ?>