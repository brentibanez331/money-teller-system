</div> <!--Note: this is end of the .min-h-full-->
<?php /**PATH C:\Users\Acer\projectasdfasdf\resources\views/auth/layouts/footer.blade.php ENDPATH**/ ?>