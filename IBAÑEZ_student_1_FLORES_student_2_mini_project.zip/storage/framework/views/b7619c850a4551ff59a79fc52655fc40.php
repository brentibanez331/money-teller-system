</div> <!--Note: this is end of the .min-h-full-->
<?php /**PATH C:\Users\Acer\money-teller\resources\views/auth/layouts/footer.blade.php ENDPATH**/ ?>