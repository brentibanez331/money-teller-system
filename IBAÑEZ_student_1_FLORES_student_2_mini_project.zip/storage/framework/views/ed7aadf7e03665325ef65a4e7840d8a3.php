<div class="min-h-full">
<?php /**PATH C:\Users\Acer\projectasdfasdf\resources\views/auth/layouts/header.blade.php ENDPATH**/ ?>