<div class="min-h-full">
<?php /**PATH C:\Users\Acer\money-teller\resources\views/auth/layouts/header.blade.php ENDPATH**/ ?>