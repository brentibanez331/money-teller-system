<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <title>Document</title>
</head>
<body class="bg-[#1b1b1b] text-white">
    <main>
        <p>Testing</p>
        <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($recipe->product_name); ?></p>
        <div><?php echo e($recipe->quantity); ?></div>
        <div><?php echo e($recipe->price); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <a href="/add-recipes" class="bg-cyan-700 p-3">+ Add Recipes</a>
    </main>
    
</body>
</html><?php /**PATH C:\Users\Acer\money-teller\resources\views/recipes/index.blade.php ENDPATH**/ ?>