</div> <!--Note: this is end of the .min-h-full-->

<footer class="relative pt-8 pb-6 mt-16">
  <div class="container mx-auto px-4">
    <div class="flex flex-wrap items-center md:justify-between justify-center">
      <div class="w-full md:w-6/12 px-4 mx-auto text-center">
        <div class="text-sm text-blueGray-500 font-semibold py-1">
          Phonebook developed by You
        </div>
      </div>
    </div>
  </div>
</footer>