@extends('layouts.app')

@section('content')

<!-- Hello wordwrap -->
<Field>
      <Label>Full name</Label>
      <Input name="full_name" />
    </Field>

@endsection

